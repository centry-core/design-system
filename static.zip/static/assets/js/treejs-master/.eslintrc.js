module.exports = {
  extends: ['eslint-config-airbnb-base', 'eslint-config-prettier'],
};
